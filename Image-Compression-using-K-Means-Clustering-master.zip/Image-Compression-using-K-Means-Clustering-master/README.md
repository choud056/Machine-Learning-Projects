# Image-Compression-using-K-Means-Clustering

This Folder contains following files:
1. An  Ipython notebook for implementing K-means Clustering Algorithm to compress an image of a bird to 16 colors.
2. An PDF file with instruction that I followed for this project
3. An image of a bird to be compressed
4. A .mat file to that was used to validate the implemented K-means Clustering algorithm
